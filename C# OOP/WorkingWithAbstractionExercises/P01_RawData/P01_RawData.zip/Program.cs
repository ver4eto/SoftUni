﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P01_RawData
{
   
    class RawData
    {
        static void Main(string[] args)
        {
            Runner runner = new Runner();
            runner.Run();
        }
    }
}
