﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P02_CarsSalesman
{
    public class StartUp
    {
       public static void Main(string[] args)
        {
            Runner runner = new Runner();
            runner.Run();
        }
    }

}
