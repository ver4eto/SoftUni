﻿using System;
using System.Linq;

namespace P03_JediGalaxy
{
   public class Program
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
