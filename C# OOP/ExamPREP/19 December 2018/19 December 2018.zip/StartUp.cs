﻿using SoftUniRestaurant.Core;

namespace SoftUniRestaurant
{
    public class StartUp
    {
        public static void Main()
        {
            Runner runner = new Runner();
            runner.Run();
        }
    }
}
