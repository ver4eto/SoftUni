﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Operations
{
    public class MathOperations
    {
        public int Add(int intOne, int intTwo)
        {
            return intOne + intTwo;
        }

        public double Add(double one, double two,double three)
        {
            return one + two + three;
        }

        public decimal Add(decimal a, decimal b, decimal c)
        {
            return a + b + c;
        }
    }
}
