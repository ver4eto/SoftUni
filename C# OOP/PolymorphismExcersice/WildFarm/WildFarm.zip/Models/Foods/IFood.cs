﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Foods
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
