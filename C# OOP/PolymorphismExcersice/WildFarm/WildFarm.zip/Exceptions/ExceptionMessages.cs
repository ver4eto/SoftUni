﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public static string InvalidFoodType = "{0} does not eat {1}!";
    }
}
