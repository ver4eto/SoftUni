﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo.Mammal
{
    public class Gorilla : Mammal
    {
        public Gorilla(string name) 
            : base(name)
        {
        }
    }
}
