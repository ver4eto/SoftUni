﻿
namespace Logger.Contracts
{
   public interface ILayout
    {

        string Format { get; }
    }
}
