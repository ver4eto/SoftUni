﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Exceptions
{
    public class ExceptionMessages
    {

        public const string InvalidNumber ="Invalid number!" ;

        public const string InvalidURL = "Invalid URL!";
    }
}
